# QuickValkyrieForAutisticPeople
a tera meme
