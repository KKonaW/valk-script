# ValkRuneburst

Module that makes it possible to cancel runeburst earlier by cutting the animation short.

## Important Update

In discussion with some members of the Valkyrie community, we noticed a "bug".

If you use a skill meanwhile runeburst hits are still ongoing you will lose your Dreamblaze buff. Thats why you can now choose your amount of runes to cancel at if you prefer to keep the damage somewhat higher...

- If you know of ways to prevent the bug or improve the canceling feel free to contact me on Discord : KYGAS#8575
- ~~Lowkey but also highkey lf an e-girl, hmu~~ Found my wifeu, thanks all for the applications :UwU:

# Commands:

!valkrb - toggle on-off

!valkrb on - toggle on

!valkrb off - toggle off

!valkrb delay {VALUE} - sets the delay for cancel to VALUE ( in milliseconds )

!valkrb hits {VALUE} - sets the optimal number of runes to cancel runeburst at !if you have less runes stacked it will cancel after the last hits!

!valkrb mode {VALUE} - sets the mode used to cancel runeburst. { hits or delay }. Hits mode will cancel it after the set amount of hits or after the last hit if less or equal to the set amount. Delay mode will cancel it after the set delay.

!valkrb mode {VALUE} - sets the mode used to cancel runeburst. { hits or delay }. Hits mode will cancel it after the set amount of hits or after the last hit if less or equal to the set amount. Delay mode will cancel it after the set delay.

!valkrb ping {VALUE} - idk why I named it myAveragePing but if you notice that you are losing your dreamblaze buff with hits method, increase this value... can be negative if you want "safe cancel" to be faster, etc...
